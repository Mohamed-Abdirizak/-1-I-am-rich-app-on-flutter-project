package com.example.iamrichapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
